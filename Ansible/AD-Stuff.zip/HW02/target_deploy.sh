openstack server delete win11_target
openstack server delete winServ_target
openstack server create --flavor medium --image Win11-21H2 --key-name ansible --network MAIN-NAT --user-data win_setup.ps1 win11_target
openstack server create --flavor medium --image WinSrv2022-20348-2022 --user-data win_setup.ps1 --key-name ansible --network MAIN-NAT winServ_target
